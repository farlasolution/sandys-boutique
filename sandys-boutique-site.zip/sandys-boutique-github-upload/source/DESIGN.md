---
name: Sandy’s Boutique & Gifts
description: A warm, editorial welcome to a local boutique.
colors:
  navy: "#1a2039"
  navy-light: "#2b3352"
  ink: "#202642"
  rose: "#ef91b0"
  rose-dark: "#9f405f"
  paper: "#efeeeb"
  paper-warm: "#e9e7e3"
  paper-rose: "#eee5e6"
  light-ink: "#f1f2f4"
  rose-note: "#f3c7d2"
typography:
  display:
    fontFamily: "STIX Two Text, Georgia, serif"
    fontSize: "clamp(48px, 5vw, 72px)"
    fontWeight: 400
    lineHeight: 0.99
    letterSpacing: "-0.035em"
  headline:
    fontFamily: "STIX Two Text, Georgia, serif"
    fontSize: "clamp(40px, 4vw, 56px)"
    fontWeight: 400
    lineHeight: 1.02
    letterSpacing: "-0.03em"
  body:
    fontFamily: "STIX Two Text, Georgia, serif"
    fontSize: "18px"
    fontWeight: 400
    lineHeight: 1.45
  label:
    fontFamily: "STIX Two Text, Georgia, serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.45
rounded:
  paper: "16px"
  focus: "2px"
spacing:
  frame: "12px"
  reading-gutter: "clamp(26px, 4.2vw, 66px)"
components:
  button-primary:
    backgroundColor: "{colors.navy}"
    textColor: "{colors.paper}"
    typography: "{typography.body}"
    rounded: "0px"
    padding: "12px 19px"
    height: "52px"
---

# Design System: Sandy’s Boutique & Gifts

## Overview

**Creative North Star: “A Local Boutique Welcome”**

The visual system offers a warm, quiet, editorial welcome to a local boutique. STIX Two Text and generous paper fields give it a composed, printed character while keeping the address and four category names clear and useful. On the homepage, the postcard from Lewis Road is the page composition: its postal stripe, postmark, and reading card organize the visit invitation without defining every future surface.

The visual balance is warm and restrained: navy grounds the page, rose adds a small postal accent, and neutral paper carries the reading column. The editorial photograph provides the main visual focus and follows the category being read. Generated imagery is illustrative styling imagery, not a depiction of confirmed store interiors or inventory.

**Key Characteristics:**
- Warm, quiet, editorial postcard character.
- Navy, rose, and neutral paper as broad printed fields.
- Clear serif typography, flat surfaces, and one rectangular directions action.
- A slow crossfading editorial photo paired with the reading column.

## Colors

The palette pairs deep navy ink and restrained rose with warm neutral paper; photo color stays within the illustrative image rather than adding interface colors.

### Primary
- **Postmark Navy** (`{colors.navy}`): Page ground, directions action, and dark visit/footer sections.
- **Rose Ink** (`{colors.rose}`): Postal stripe, small accents, and selected headings against navy.

### Secondary
- **Deep Rose** (`{colors.rose-dark}`): Hover and focus contrast on paper surfaces.
- **Navy Light** (`{colors.navy-light}`): Underlying tone behind the photographic area.

### Neutral
- **Printed Ink** (`{colors.ink}`): Main text on paper.
- **Postcard Stock** (`{colors.paper}`): Main reading surface and the action's light text.
- **Warm Stock** (`{colors.paper-warm}`): Alternate paper sections.
- **Blush Stock** (`{colors.paper-rose}`): Alternating category sections.
- **Light Ink** (`{colors.light-ink}`): Text on navy fields and image captions.
- **Rose Note** (`{colors.rose-note}`): Small footer note on navy.

**The Paper Field Rule.** Use paper tones as broad section surfaces and reserve rose for accents; do not scatter color as decoration without a page role.

## Typography

**Display Font:** STIX Two Text (with Georgia, serif fallback)  
**Body Font:** STIX Two Text (with Georgia, serif fallback)

**Character:** One literary serif family gives wordmark, headings, navigation, and body a coherent printed voice. Tight tracking and compact display leading keep large headlines composed rather than ornamental.

### Hierarchy
- **Display** (400, `clamp(48px, 5vw, 72px)`, 0.99 line-height): The two-line homepage welcome; mobile scales to `clamp(39px, 10vw, 48px)`.
- **Headline** (400, `clamp(40px, 4vw, 56px)`, 1.02–1.03 line-height): Category and visit section headings; 40px on mobile.
- **Title** (600, 32px wordmark; 24px image caption): Brand mark and photo caption.
- **Body** (400, 18px, 1.45 line-height): Supporting copy and address; measures are held to roughly 31–35ch on the welcome section.
- **Label** (400, 14–16px, 1.45 line-height): Small address details, image note, navigation, and supporting wordmark line.

**The One Serif Rule.** Keep interface and editorial text in STIX Two Text; let size, weight, and spacing create hierarchy.

## Layout

On desktop, a split stage places the scrolling paper reading card beside a sticky editorial photo, separated by a 12px frame and gap and capped at 1720px. The card uses generous responsive side gutters (`clamp(26px, 4.2vw, 66px)`) and spacious sections. Below 1050px, the header stacks; below 680px, the image leads and the paper card follows with a 22px overlap. At 390px and below, the header and reading gutters tighten again. Category sections remain in a stable, readable sequence.

## Elevation & Depth

The system is flat and printed, with no box shadows. Depth comes from the dark page ground around the paper card, alternating paper tones, and the full-height photograph. Dark translucent caption and note panels keep type legible over the image.

**The Flat Print Rule.** Keep resting surfaces shadow-free; use color fields and the photograph to distinguish layers.

## Shapes

The postcard and photo stage use gently rounded 16px corners. The directions action is a crisp rectangle with no radius. Postal stripes and thin circular postmarks are small signature graphics; keep them as restrained print marks rather than a general shape language.

## Components

### Buttons
- **Character:** Crisp, direct, and easy to spot within the paper field.
- **Primary:** A solid navy rectangular directions link with paper text, 52px minimum height, and 12px 19px padding.
- **Hover / Active:** Rose fill with navy text; the rose arrow shifts diagonally. Active state moves down 1px.
- **Focus:** Links receive a 3px deep-rose outline with 4px offset.

### Navigation
- **Style:** Text-only category links in the shared serif, arranged in a flexible row at the top of the card.
- **Hover:** Deep-rose text with an underline; the underline color fades in over 180ms.
- **Mobile:** Links spread across the card width and may wrap as needed.

### Editorial Photo Stage
- **Style:** A full-height, sticky, rounded photo stage on desktop; at mobile it sits first and overlaps the card below.
- **Behavior:** The image follows the visible category with a 1500ms crossfade. Captions and the illustrative-imagery note sit on translucent navy fields.
- **Reduced motion:** Transitions collapse, content remains visible, and only the first image is shown.

## Do's and Don'ts

### Do:
- **Do** use the paper card for real page content: clear category links, readable copy, and the supplied address.
- **Do** keep the directions action rectangular, navy, and visually distinct.
- **Do** label generated styling imagery as illustrative.
- **Do** preserve visible keyboard focus and the reduced-motion treatment.

### Don't:
- **Don't** add shadows to resting surfaces.
- **Don't** imply the generated photos show the actual shop or confirmed inventory.
- **Don't** introduce unconfirmed business details such as hours, prices, brands, or testimonials.
- **Don't** add commerce or operational interactions to this visual-only system.
