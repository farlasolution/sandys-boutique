# Mockup image sources

These four images were generated for this mockup and are illustrative styling imagery, not photographs of Sandy’s store or confirmed products. Replace them with approved store and inventory photographs before a real launch.

## `boutique-hero.jpg`

Use case: website hero photography. Asset type: portrait hero photograph for an independent women’s boutique website. Prompt: “A confident, warmly candid woman in her late 30s wearing a beautifully styled everyday outfit from a small-town women’s boutique, photographed from mid-thigh up. Outfit: deep navy blouse, soft blush skirt, understated jewelry. Sunlit old-fashioned boutique interior with a few clothing rails and a large window, tasteful and lived-in, no readable signs. Premium fashion editorial photography, natural and human, not glossy luxury advertising. Portrait 4:5, subject slightly right of center with enough environment around her, vertical crop suitable for a full-height website panel. Soft afternoon window light, warm welcoming, small-town charm. Navy, dusty rose, pale butter, natural wood. No logos, text, watermark, brand marks, product labels, or real named person.”

## `jewelry.jpg`

Use case: product category photography. Asset type: editorial still life for the jewelry category. Prompt: “A small curated arrangement of tasteful gold-tone earrings, delicate necklaces, and a simple jewelry dish, like a boutique display. Rich navy cloth beside a pale blush paper gift box on a warm wooden counter. Refined product still-life photography, realistic materials and scale, tactile and understated. Portrait 4:5, close composition with breathing room, no legible labels. Soft directional daylight, warm and inviting. Navy, blush pink, brass, warm wood. No logos, text, watermark, branded packaging. Illustrative display only.”

## `purses.jpg`

Use case: product category photography. Asset type: editorial still life for the purses category. Prompt: “A beautifully made medium-sized everyday handbag in a soft cognac leather tone with subtle brass hardware, paired with a folded dusty-rose scarf. Boutique display table with a dark navy fabric backdrop and pale wall. Premium but approachable independent-shop product photography, no visible brand. Portrait 4:5, bag shown fully with generous margin, three-quarter angle. Soft afternoon window light, warm and tactile. Cognac, navy, blush, pale butter. No logos, text, watermark, or identifiable brand marks. Illustrative styling, not actual store inventory.”

## `gifts.jpg`

Use case: product category photography. Asset type: editorial still life for gift items. Prompt: “A thoughtful small gift arrangement: a pale butter gift box tied with a dusty-rose ribbon, a blank card, and a small candle in glass. Warm wooden shop counter, folded navy cloth and soft daylight. Refined independent boutique still-life photography, welcoming and personal, realistic. Portrait 4:5, close crop but show the whole arrangement and some negative space. Golden afternoon window light. Pale butter, dusty rose, navy, natural wood. No readable writing, logos, text, watermark, or brands. Illustrative styling only.”
