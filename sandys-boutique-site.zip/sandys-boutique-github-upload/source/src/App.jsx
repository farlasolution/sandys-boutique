import { useEffect, useState } from 'react';

const scenes = [
  {
    id: 'welcome',
    src: '/assets/boutique-hero.jpg',
    alt: 'A woman in a navy blouse and blush skirt inside a sunlit boutique.',
    caption: 'Sandy’s Boutique & Gifts',
  },
  {
    id: 'jewelry',
    src: '/assets/jewelry.jpg',
    alt: 'Gold-tone jewelry arranged on navy cloth beside a blush gift box.',
    caption: 'Jewelry',
  },
  {
    id: 'purses',
    src: '/assets/purses.jpg',
    alt: 'A cognac-colored handbag with a blush scarf on a boutique display table.',
    caption: 'Purses',
  },
  {
    id: 'gifts',
    src: '/assets/gifts.jpg',
    alt: 'A pale gift box tied with a rose ribbon on a wooden counter.',
    caption: 'Gift items',
  },
];

const directionsUrl = 'https://maps.google.com/?q=11+Lewis+Rd%2C+Gallipolis%2C+OH+45631';

function Postmark() {
  return (
    <span className="postmark" aria-hidden="true">
      <span className="postmark__ring" />
      <span className="postmark__letter">S</span>
    </span>
  );
}

function SiteHeader({ page = 'home' }) {
  return (
    <header className="site-header">
      <a className="wordmark" href="/" aria-label="Sandy’s Boutique and Gifts, home">
        <span className="wordmark__main">Sandy’s</span>
        <span className="wordmark__sub">Boutique &amp; Gifts</span>
      </a>
      <nav className="main-nav" aria-label="Main navigation">
        {page !== 'home' && <a href="/">Home</a>}
        <a href="/about/" aria-current={page === 'about' ? 'page' : undefined}>About</a>
        <a href="/contact/" aria-current={page === 'contact' ? 'page' : undefined}>Contact</a>
        {page === 'home' && (
          <>
            <a href="#clothing">Clothing</a>
            <a href="#jewelry">Jewelry</a>
            <a href="#purses">Purses</a>
            <a href="#gifts">Gifts</a>
          </>
        )}
      </nav>
    </header>
  );
}

function PhotoStage({ activeScene = 'welcome', arrival = false }) {
  return (
    <aside className={`photo-stage${arrival ? ' photo-stage--arrival' : ''}`} aria-label="Illustrative boutique and product photographs">
      <div className="photo-stack">
        {scenes.map((scene, index) => (
          <img
            className={`photo-stack__image${activeScene === scene.id ? ' is-active' : ''}`}
            key={scene.id}
            src={scene.src}
            alt={scene.alt}
            fetchPriority={index === 0 ? 'high' : undefined}
            loading={index === 0 ? 'eager' : 'lazy'}
          />
        ))}
      </div>
      <div className="photo-stage__veil" aria-hidden="true" />
      <div className="photo-stage__signature">
        <p className="photo-stage__caption" aria-live="polite">
          {scenes.find((scene) => scene.id === activeScene)?.caption ?? scenes[0].caption}
        </p>
        <Postmark />
      </div>
      <p className="photo-stage__note">Illustrative styling imagery</p>
    </aside>
  );
}

function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="stripe-band stripe-band--footer" aria-hidden="true" />
      <p>Sandy’s Boutique &amp; Gifts</p>
      <p>11 Lewis Rd, Gallipolis, OH 45631</p>
      <small>Mockup imagery is illustrative.</small>
    </footer>
  );
}

function HomePage() {
  const [activeScene, setActiveScene] = useState('welcome');

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion || !('IntersectionObserver' in window)) return undefined;

    document.documentElement.classList.add('motion-ready');
    const sections = document.querySelectorAll('[data-scene]');
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveScene(visible.target.dataset.scene);
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('is-visible');
        });
      },
      { rootMargin: '-25% 0px -35% 0px', threshold: [0, 0.15, 0.35, 0.65] },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <main className="site-frame">
      <div className="split-stage">
        <PhotoStage activeScene={activeScene} />

        <div className="postcard">
          <div className="stripe-band" aria-hidden="true" />
          <SiteHeader />

          <section className="story-section hero" id="home" data-scene="welcome">
            <h1>A lovely day<br className="desktop-break" /> starts here.</h1>
            <p className="hero__description">
              Women’s clothing, jewelry, purses and gifts at 11 Lewis Rd in Gallipolis.
            </p>
            <a className="visit-button" href={directionsUrl} target="_blank" rel="noreferrer">
              Get directions <span className="visit-button__arrow" aria-hidden="true">↗</span>
            </a>
            <p className="hero__address">Gallipolis, Ohio <span>·</span> 45631</p>
          </section>

          <section className="story-section category-intro" id="discover">
            <h2>Good things to find.</h2>
            <p>Browse by category, then come see the assortment in person.</p>
          </section>

          <section className="story-section category-section" id="clothing" data-scene="welcome">
            <h2>Women’s clothing</h2>
            <p>Pieces for the everyday, and the plans you look forward to.</p>
          </section>

          <section className="story-section category-section category-section--rose" id="jewelry" data-scene="jewelry">
            <h2>Jewelry</h2>
            <p>A small detail can make an outfit feel like yours.</p>
          </section>

          <section className="story-section category-section" id="purses" data-scene="purses">
            <h2>Purses</h2>
            <p>Find a favorite to take along for the day.</p>
          </section>

          <section className="story-section category-section category-section--rose" id="gifts" data-scene="gifts">
            <h2>Gift items</h2>
            <p>For a celebration, a thank-you, or just because.</p>
          </section>

          <section className="story-section visit-section" id="visit" data-scene="gifts">
            <h2>Come see us.</h2>
            <div className="visit-section__stamp" aria-hidden="true"><span>Sandy’s</span></div>
            <address>11 Lewis Rd<br />Gallipolis, OH 45631</address>
            <a className="visit-link" href={directionsUrl} target="_blank" rel="noreferrer">
              Get directions
            </a>
          </section>

          <SiteFooter />
        </div>
      </div>
    </main>
  );
}

function InformationPage({ page }) {
  const isAbout = page === 'about';

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion || !('IntersectionObserver' in window)) return undefined;

    document.documentElement.classList.add('motion-ready');
    const section = document.querySelector('[data-scene]');
    if (!section) return undefined;
    section.classList.add('is-visible');

    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('is-visible');
      }),
      { rootMargin: '-25% 0px -35% 0px', threshold: [0, 0.15, 0.35, 0.65] },
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <main className="site-frame information-page">
      <div className="split-stage">
        <PhotoStage activeScene={isAbout ? 'welcome' : 'gifts'} arrival />
        <div className="postcard">
          <div className="stripe-band" aria-hidden="true" />
          <SiteHeader page={page} />

          {isAbout ? (
            <section className="story-section simple-page__content" id="about" data-scene="welcome">
              <h1>A local boutique welcome.</h1>
              <p className="simple-page__intro">
                Sandy’s Boutique &amp; Gifts is in Gallipolis, Ohio, offering women’s clothing, jewelry, purses and gift items.
              </p>
              <a className="visit-button" href={directionsUrl} target="_blank" rel="noreferrer">
                Get directions <span className="visit-button__arrow" aria-hidden="true">↗</span>
              </a>
              <address>11 Lewis Rd<br />Gallipolis, OH 45631</address>
            </section>
          ) : (
            <section className="story-section simple-page__content contact-page__content" id="contact" data-scene="gifts">
              <h1>Find us in Gallipolis.</h1>
              <address>11 Lewis Rd<br />Gallipolis, OH 45631</address>
              <a className="visit-button" href={directionsUrl} target="_blank" rel="noreferrer">
                Get directions <span className="visit-button__arrow" aria-hidden="true">↗</span>
              </a>
            </section>
          )}

          <SiteFooter />
        </div>
      </div>
    </main>
  );
}

function App() {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (path === '/about') return <InformationPage page="about" />;
  if (path === '/contact') return <InformationPage page="contact" />;
  return <HomePage />;
}

export default App;
