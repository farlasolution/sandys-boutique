# Sandy’s Boutique & Gifts — HighLevel HTML export

This export contains one self-contained HTML file per page. The CSS and production JavaScript are inline, the mockup images are embedded, and the postal stripe is embedded as SVG. The page uses a Google Fonts stylesheet with a Georgia fallback.

## Upload in HighLevel

This export is for HighLevel WordPress Hosting → Custom HTML Pages. It is not an import for the drag-and-drop Website Builder.

1. In HighLevel, go to **Sites → WordPress** and open **Manage Website**.
2. Open **Pages → Upload New HTML Page**.
3. Upload each file separately, then preview and publish it:
   - home.html — homepage/root page where supported
   - about.html — set the slug to /about
   - contact.html — set the slug to /contact
4. Keep the slugs exactly as shown so the navigation links work.
5. Assign the Home page as the site’s root/default page, then verify all three pages on desktop and mobile.

HighLevel’s uploader accepts one HTML file at a time and has a 5 MB per-file limit; these three files are each below that limit. The page files do not depend on a sibling assets folder.

## Notes

- This remains a visual mockup: the only external action is the Google Maps directions link.
- Generated boutique/product images are illustrative, not confirmed photos of the store or inventory.
- No hours, phone number, email address, form, or shopping functionality is included.
- Uploading HTML pages does not make their source editable in HighLevel’s drag-and-drop builder. To change the page, edit the source here, regenerate the export, and upload a new version.
